package models.responses;

public class GistResponse {

}
