"""A simple setup file for this test package."""

from setuptools import setup

setup(
    name="pypiserver_mypkg",
    description="Test pkg",
    version="1.0.0",
    packages=["mypkg"],
)
