"""A very simple python file to package for testing."""


def pkg_name() -> None:
    """Print the package name."""
    print("mypkg")
